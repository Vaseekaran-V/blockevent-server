"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class requestModel {
    constructor(id, latitude, longitude, type, status, description, email) {
        this.request = () => { return new requestModel("", null, null, "", "", "", ""); };
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.type = type;
        this.status = status;
        this.description = description;
        this.email = email;
    }
}
exports.requestModel = requestModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVxdWVzdE1vZGVsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmVxdWVzdE1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsTUFBYSxZQUFZO0lBU3ZCLFlBQ0UsRUFBVSxFQUNWLFFBQWdCLEVBQ2hCLFNBQWlCLEVBQ2pCLElBQVksRUFDWixNQUFjLEVBQ2QsV0FBbUIsRUFDbkIsS0FBYTtRQVlWLFlBQU8sR0FBQyxHQUFFLEVBQUUsR0FBRSxPQUFPLElBQUksWUFBWSxDQUFDLEVBQUUsRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxFQUFFLEVBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUEsQ0FBQyxDQUFBO1FBVmxFLElBQUksQ0FBQyxFQUFFLEdBQUMsRUFBRSxDQUFDO1FBQ1gsSUFBSSxDQUFDLFFBQVEsR0FBQyxRQUFRLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBQyxTQUFTLENBQUM7UUFDekIsSUFBSSxDQUFDLElBQUksR0FBQyxJQUFJLENBQUM7UUFDZixJQUFJLENBQUMsTUFBTSxHQUFDLE1BQU0sQ0FBQztRQUNuQixJQUFJLENBQUMsV0FBVyxHQUFDLFdBQVcsQ0FBQztRQUM3QixJQUFJLENBQUMsS0FBSyxHQUFDLEtBQUssQ0FBQztJQUVyQixDQUFDO0NBS0Y7QUEvQkQsb0NBK0JDIn0=